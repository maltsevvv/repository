#!/usr/bin/env python
from __future__ import print_function

import xbmc
import xbmcgui
import os
import re
import binascii
import can
import time
import threading  # Добавлен импорт для threading
import config

from dumpcan import activate_addon # Активация
from bluetooth import bt_next, bt_prev, bt_disconnect, a2dpinfo
from config import rns_setup, rns_tft, encoder_left, encoder_right, mfsw_up, mfsw_down, mfsw_left, mfsw_right, mfsw_fis_left, mfsw_fis_right
from config import get_property, up_btn, down_btn, left_btn, right_btn, encoder_btn, back_btn, setup_btn

bus = can.Bus(interface='socketcan', channel='can0', receive_own_messages=True)
# Глобальная переменная для эмуляции ТВ-тюнера
NumTx = 0

last_2001_time = None

# Эмуляция: Отправка для активации выполняется один раз при загрузки, если условие истинно
if config.emulation_rnsdtv == 'true':
    os.system('cansend can0 464#E00100')

def send_can_message(can_id, data_hex):
    cmd = f'cansend can0 {can_id}#{data_hex}'
    os.system(cmd)

def handle_rns_d(msg):
    global NumTx
    global last_2001_time
    data = bytes.fromhex(msg)
    properties = get_property()  # Получаем свойства здесь
    bt_connect = properties.get('BT_CONNECT')  # Используем свойства
    window_home = properties.get('WINDOW_HOME')
    window_dashboard = properties.get('WINDOW_DASHBOARD')
    if config.emulation_rnsdtv == 'true':
        if len(data) == 3 and msg == 'E00100':
            NumTx = 0
            send_can_message('264', 'E00100')
        # Video timings data (?)
        elif len(data) == 2 and msg == 'E101':
            send_can_message('264', '10150100020000')
            NumTx += 1
            send_can_message('264', f'{(NumTx & 0x0F) + 0x10:02X}270200')
        # Ping - Pong
        elif len(data) == 2 and msg == 'A300':
            send_can_message('264', 'E101')
        # ACK for all requests (if DLC > 1)
        elif len(data) > 1:
            ack_data = ((data[0] + 1) & 0x0F) + 0xB0
            send_can_message('264', f'{ack_data:02X}')
        # Purpose unknown (?)
        if len(data) == 3 and data[1] == 0x00 and data[2] == 0x01:
            NumTx += 1
            send_can_message('264', f'{(NumTx & 0x0F) + 0x10:02X}0101')
        # Purpose unknown (?)
        if len(data) == 2 and data[1] == 0x08:
            NumTx += 1
            send_can_message('264', f'{(NumTx & 0x0F) + 0x20:02X}090142500231')
        # stop tv-tuner for rnsd
        if len(data) == 3 and data[1] == 0x00 and data[2] == 0x02:
            NumTx += 1
            send_can_message('264', f'{(NumTx & 0x0F) + 0x10:02X}0102')

############################################
    if config.rnsd_remote == 'true':
        if len(msg) == 10 and msg[2:4] == '20': # Проверка префикса
            if msg[4:10] == '0100FF':    # Encoder Left
                encoder_left()
            elif msg[4:10] == '0101FF':  # Encoder Right
                encoder_right()
            elif msg[4:10] == '010005':  # Encoder Press
                xbmc.executebuiltin('Action(Select)')

            elif msg[4:10] == '010200': # UP: Начало нажатия — запоминаем время
                last_2001_time = time.time()
            elif msg[4:10] == '020200':  # UP: Конец нажатия — проверяем длительность
                if last_2001_time is not None:
                    current_time = time.time()
                    diff = current_time - last_2001_time
                    if diff <= 0.5: # Короткое нажатие (<=1 сек)
                        xbmc.executebuiltin('Action(Up)')
                    else:  # Долгое нажатие (>1 сек)
                        xbmc.executebuiltin('PlayerControl(BigSkipForward)')
                    last_2001_time = None  # Сброс после обработки
                # else:
                    # xbmc.log('RNS-D: 20020200 received without prior 20010200', xbmc.LOGWARNING)

            elif msg[4:10] == '012000': # DOWN: Начало нажатия — запоминаем время
                last_2001_time = time.time()
            elif msg[4:10] == '022000':  # DOWN: Конец нажатия — проверяем длительность
                if last_2001_time is not None:
                    current_time = time.time()
                    diff = current_time - last_2001_time
                    if diff <= 0.5: # Короткое нажатие (<=1 сек)
                        xbmc.executebuiltin('Action(Down)')
                    else:  # Долгое нажатие (>1 сек)
                        xbmc.executebuiltin('PlayerControl(BigSkipBackward)')
                    last_2001_time = None  # Сброс после обработки
                # else:
                    # xbmc.log('RNS-D: 20022000 received without prior 20012000', xbmc.LOGWARNING)

            elif msg[4:10] == '010100': # LEFT: Начало нажатия — запоминаем время
                last_2001_time = time.time()
            elif msg[4:10] == '020100':  # LEFT: Конец нажатия — проверяем длительность
                if last_2001_time is not None:
                    current_time = time.time()
                    diff = current_time - last_2001_time
                    if diff <= 0.5: # Короткое нажатие (<=1 сек)
                        xbmc.executebuiltin('Action(Left)')
                    else: # Долгое нажатие (>1 сек)
                        if (bt_connect and window_home) or (bt_connect and window_dashboard):
                            bt_prev()
                        else:
                            xbmc.executebuiltin('PlayerControl(Previous)')
                    last_2001_time = None  # Сброс после обработки
                # else:
                    # xbmc.log('RNS-D: 20020100 received without prior 20010100', xbmc.LOGWARNING)

            elif msg[4:10] == '010300': # RIGHT: Начало нажатия — запоминаем время
                last_2001_time = time.time()
            elif msg[4:10] == '020300':  # RIGHT: Конец нажатия — проверяем длительность
                if last_2001_time is not None:
                    current_time = time.time()
                    diff = current_time - last_2001_time
                    if diff <= 0.5: # Короткое нажатие (<=1 сек) 
                        xbmc.executebuiltin('Action(Right)')
                    else: # Долгое нажатие (>1 сек)
                        if (bt_connect and window_home) or (bt_connect and window_dashboard):
                            bt_prev()
                        else:
                            xbmc.executebuiltin('PlayerControl(Next)')
                    last_2001_time = None  # Сброс после обработки
                # else:
                    # xbmc.log('RNS-D: 20020300 received without prior 20010300', xbmc.LOGWARNING)

            elif msg[4:10] == '010400': # AS: Начало нажатия — запоминаем время
                last_2001_time = time.time()
            elif msg[4:10] == '020400':  # AS: Конец нажатия — проверяем длительность
                if last_2001_time is not None:
                    current_time = time.time()
                    diff = current_time - last_2001_time
                    if diff <= 0.5: # Короткое нажатие (<=1 сек)
                        xbmc.executebuiltin('Action(Select)')
                    else: # Долгое нажатие (>1 сек)
                        xbmc.executebuiltin('ActivateWindow(1100)')
                    last_2001_time = None  # Сброс после обработки
                else:
                    xbmc.log('RNS-D: 20020400 received without prior 20010400', xbmc.LOGWARNING)

            elif msg[4:10] == '010050': # RETURN: Начало нажатия — запоминаем время
                last_2001_time = time.time()
            elif msg[4:10] == '020050':  # RETURN: Конец нажатия — проверяем длительность
                if last_2001_time is not None:
                    current_time = time.time()
                    diff = current_time - last_2001_time
                    if diff <= 0.5: # Короткое нажатие (<=1 сек)
                        xbmc.executebuiltin('Action(Back)')
                    else: # Долгое нажатие (>1 сек)
                        if (bt_connect and window_home) or (bt_connect and window_dashboard):
                            bt_disconnect()
                        else:
                            xbmc.executebuiltin('PlayerControl(Stop)')
                    last_2001_time = None  # Сброс после обработки
                # else:
                    # xbmc.log('RNS-D: 20020050 received without prior 20010050', xbmc.LOGWARNING)

            elif msg[4:10] == '010003':  # MODE
                rns_setup()
            elif msg[4:10] == '010020':  # + 
                xbmc.executebuiltin('Action(Up)')
            elif msg[4:10] == '010001':  # - 
                xbmc.executebuiltin('Action(Down)')
            elif msg[6:10] == 'FF00':  # TONE + AM
                xbmc.executebuiltin('ActivateWindow(1100)')

        if len(msg) == 6 and msg[2:6] == '0002':  # TFT.OFF
            rns_tft()

# Добавленная функция для периодической отправки CAN-сообщения для RNSE TV
def rnse_tv_sender():
    while True:
        if config.emulation_rnsetv == 'true':
            os.system('cansend can0 602#8912300000000000')
        #time.sleep(0.5)
        time.sleep(2)

def handle_rns_e(msg):
    global encoder_btn, back_btn, right_btn, left_btn, setup_btn, up_btn, down_btn  # Declare
    properties = get_property()  # Получаем свойства здесь
    bt_connect = properties.get('BT_CONNECT')  # Используем свойства
    window_home = properties.get('WINDOW_HOME')
    window_dashboard = properties.get('WINDOW_DASHBOARD')
    
    if len(msg) == 12 and msg[0:4] == '3730':
        if msg[4:12] == '01004001':    # Encoder Left
            encoder_left()
        elif msg[4:12] == '01002001':  # Encoder Right
            encoder_right()
        elif msg[4:12] == '01001000':  # Encoder PRESS
            encoder_btn += 1
        elif msg[4:12] == '04001000' and encoder_btn > 0:
            if encoder_btn <= 4:       # Encoder Press
                xbmc.executebuiltin('Action(Select)')
                encoder_btn = 0
            else:                      # Encoder Press Long
                #xbmc.log(f"Select long press detected, encoder_btn={encoder_btn} - no action", xbmc.LOGINFO)
                xbmc.executebuiltin('ActivateWindow(1100)')
                encoder_btn = 0

        elif msg[4:12] == '01400000':  # UP
            up_btn += 1
        elif msg[4:12] == '04400000' and up_btn > 0:
            if up_btn <= 4:            # UP Press
                xbmc.executebuiltin('Action(Up)')
                up_btn = 0
            else:                      # UP Press Long
                #xbmc.log(f"UP long press detected, up_btn={up_btn} - no action", xbmc.LOGINFO)
                xbmc.executebuiltin('PlayerControl(BigSkipForward)')
                up_btn = 0
     
        elif msg[4:12] == '01800000':  # DOWN
            down_btn += 1
        elif msg[4:12] == '04800000' and down_btn > 0:
            if down_btn <= 4:          # DOWN Press
                xbmc.executebuiltin('Action(Down)')
                down_btn = 0
            else:                      # DOWN Press Long
                #xbmc.log(f"DOWN long press detected, down_btn={down_btn} - no action", xbmc.LOGINFO)
                xbmc.executebuiltin('PlayerControl(BigSkipBackward)')
                down_btn = 0

        elif msg[4:12] == '01010000':  # LEFT
            left_btn += 1
        elif msg[4:12] == '04010000' and left_btn > 0:
            if left_btn <= 4:          # Left Press
                xbmc.executebuiltin('Action(Left)')
                left_btn = 0
            else: # Долгое нажатие (>1 сек)
                if (bt_connect and window_home) or (bt_connect and window_dashboard):
                    bt_prev()
                    left_btn = 0
                else:
                    xbmc.executebuiltin('PlayerControl(Previous)')
                    left_btn = 0
                # xbmc.log(f"LEFT long press detected, left_btn={left_btn} - no action", xbmc.LOGINFO)

        elif msg[4:12] == '01020000':  # RIGHT
            right_btn += 1
        elif msg[4:12] == '04020000' and right_btn > 0:
            if right_btn <= 4:         # Right Press
                xbmc.executebuiltin('Action(Right)')
                right_btn = 0
            else: # Долгое нажатие (>1 сек)
                if (bt_connect and window_home) or (bt_connect and window_dashboard):
                    bt_prev()
                    right_btn = 0
                else:
                    xbmc.executebuiltin('PlayerControl(Next)')
                    right_btn = 0
                #xbmc.log(f"RIGHT long press detected, up_btn={up_btn} - no action", xbmc.LOGINFO)

        elif msg[4:12] == '01000200':  # RETURN
            back_btn += 1
        elif msg[4:12] == '04000200' and back_btn > 0:
            if back_btn <= 4:          # Return Press
                xbmc.executebuiltin('Action(Back)')
                back_btn = 0
            else: # Долгое нажатие (>1 сек)
                if (bt_connect and window_home) or (bt_connect and window_dashboard):
                    bt_disconnect()
                else:
                    xbmc.executebuiltin('PlayerControl(Stop)')
                    back_btn = 0
                
        elif msg[4:12] == '01000100':  # SETUP
            setup_btn += 1
        elif msg[4:12] == '04000100' and setup_btn > 0:
            if setup_btn <= 4:         # Setup Press
                rns_setup()
                setup_btn = 0
            else:                      # Setup Press Long
                xbmc.executebuiltin('ActivateWindow(1100)')
                setup_btn = 0

    # # Если сообщение не подошло, логируем
    # xbmc.log(f"handle_rns_e: Unhandled msg={msg}", xbmc.LOGINFO)
    # if len(msg) < 12:  # Проверка длины, чтобы избежать ошибок индексации
        # xbmc.log(f'dumpcan: 461: {msg}', xbmc.LOGWARNING)
        # return

    if len(msg) == 12 and msg[0:4] == '3770':
        if msg[4:12] == '00000000':    # TFT OFF
            rns_tft()

def handle_mfsw(msg):
    if msg == '3902': #🔼
        mfsw_up()
    if msg == '3903': #🔽
        mfsw_down()

    if msg == '3905': #◀
        mfsw_left()

    if msg == '3904': #▶
        mfsw_right()

    if msg == '3A05': #FIS LEFT  <|
        mfsw_fis_left()

    if msg == '3A04': #FIS Right  |>
        mfsw_fis_right()

def handle_canbus_key(msg): #🔑
    if (msg[0:2] == '10' or msg[0:2] == '00'):
        canbus_keycar()



def handle_canbus_msg(msg, canid):
    if canid == '635':  # Light
        light = int(msg[2:4], 16)
        xbmcgui.Window(10000).setProperty('CanBusLight', '1' if light > 0 else '')
    elif canid == '623':  # Time
        msg = re.sub(r'\s+', '', msg)
        if len(msg) >= 16:
            a_hour = int(msg[2:4], 16)
            a_min = int(msg[4:6], 16)
            a_sec = int(msg[6:8], 16)
            value = f'{a_hour}:{a_min}:{a_sec}' if msg[12:14] != '20' else f'{msg[2:4]}:{msg[4:6]}:{msg[6:8]}'
            xbmcgui.Window(10000).setProperty('CanBusTime', value)
    elif canid in ['346', '351']:  # Speed
        msg = re.sub(r'\s+', '', msg)
        speed = int(msg[4:6] + msg[2:4], 16)
        value = str(round(speed / 200))
        xbmcgui.Window(10000).setProperty('CanBusSpeed', value)
    elif canid in ['347', '353', '35B']:  # RPM & Coolant
        msg = re.sub(r'\s+', '', msg)
        rpm = int(msg[4:6] + msg[2:4], 16)
        xbmcgui.Window(10000).setProperty('CanBusRPM', str(round(rpm / 4)))
        coolant = int(msg[6:8], 16)
        xbmcgui.Window(10000).setProperty('CanBusCoolant', str(round(coolant * 0.75 - 48)))

# Словарь обработчиков для легкого добавления новых CAN ID
handlers = {
    '464': handle_rns_d,
    '461': handle_rns_e,
    '5C3': handle_mfsw,
    '271': lambda msg: handle_canbus_key(msg, '271'),
    '345': lambda msg: handle_canbus_key(msg, '345'),
    '635': lambda msg: handle_canbus_msg(msg, '635'),
    '623': lambda msg: handle_canbus_msg(msg, '623'),
    '346': lambda msg: handle_canbus_msg(msg, '346'),
    '351': lambda msg: handle_canbus_msg(msg, '351'),
    '347': lambda msg: handle_canbus_msg(msg, '347'),
    '353': lambda msg: handle_canbus_msg(msg, '353'),
    '35B': lambda msg: handle_canbus_msg(msg, '35B'),
}

# Список разрешенных CAN ID (можно расширить)
allowed_canids = ['464', '461', '661', '5C3', '635', '623', '346', '347', '351', '353', '35B']

def control():
    encoder_btn = 0
    back_btn = 0
    right_btn = 0
    left_btn = 0
    setup_btn = 0
    up_btn = 0
    down_btn = 0

    threading.Thread(target=rnse_tv_sender, daemon=True).start()

    while True:
        try:
            for message in bus:
                canid = str(hex(message.arbitration_id).lstrip('0x').upper())
                msg = binascii.hexlify(message.data).decode('ascii').upper()
                # xbmc.log(f'Control: Received CAN ID {canid}, Data {msg}', xbmc.LOGDEBUG)  # Отладка
                if canid in allowed_canids and canid in handlers:
                    handlers[canid](msg)
        except Exception as e:
            xbmc.log(f'Control: Exception {str(e)}', xbmc.LOGFATAL)
            time.sleep(1)
