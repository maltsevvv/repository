#!/usr/bin/env python
import sys
import os
import xbmc
import can
import datetime
import glob
import urllib3
import subprocess
import logging  # Для логов
import requests  # Для отправки сообщений в Telegram

# Настройка логирования (в файл для отладки)
logging.basicConfig(filename='/home/pi/script_log.txt', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Импорт конфигурации из config.py (если есть .pyc, Python использует его автоматически)
try:
    import config
    BOT = config.BOT_TOKEN
    ID = config.CHAT_ID
except ImportError as e:
    logging.error(f"Failed to import config: {e}")
    xbmc.executebuiltin('Notification(ERROR, Config import failed)')
    sys.exit(1)

# Остальные переменные
datetime_str = datetime.datetime.now().strftime('%y-%m-%d_%H-%M-%S')
logdir = "/home/pi/log/"
MSG = "Лог CAN-шины от " + datetime_str  # Подпись для документа

xbmc.executebuiltin('Notification(Start, Log CAN-Bus Create)')

try:
    # Создание директории
    subprocess.run(['mkdir', '-p', logdir], check=True)
    
    # Логирование CAN (с таймаутом, если нужно; n 8000 - ждёт 8000 сообщений)
    log_file = logdir + 'canlog-' + datetime_str + '.log'
    cmd = f'candump can0 -ta -a -n 40 | sudo tee {log_file}'
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=350)  # Таймаут 5 минут
    if result.returncode != 0:
        logging.error(f"candump failed: {result.stderr}")
        xbmc.executebuiltin('Notification(ERROR, CAN dump failed)')
        sys.exit(1)
    
    xbmc.executebuiltin('Notification(Finish, Log CAN-Bus Created)')
    
    # Поиск последнего файла
    list_of_files = glob.glob(logdir + '*')
    if not list_of_files:
        logging.error("No log files found")
        xbmc.executebuiltin('Notification(ERROR, No log files)')
        sys.exit(1)
    latest_file = max(list_of_files, key=os.path.getmtime)
    
    # Проверка интернета
    def check_internet_conn():
        try:
            http = urllib3.PoolManager(timeout=3.0)
            r = http.request('GET', 'http://google.com', preload_content=False)
            code = r.status
            r.release_conn()
            return code == 200
        except Exception as e:
            logging.error(f"Internet check failed: {e}")
            return False
    
    # Отправка через requests (лог пишется всегда, отправка только если есть интернет)
    def send():
        if check_internet_conn():
            try:
                url = f'https://api.telegram.org/bot{BOT}/sendDocument'
                with open(latest_file, 'rb') as f:
                    response = requests.post(url, data={'chat_id': ID, 'caption': MSG}, files={'document': f})
                if response.status_code == 200:
                    xbmc.executebuiltin('Notification(Log CAN-Bus, Send to Telegram Bot)')
                    logging.info("Log sent to Telegram")
                else:
                    logging.error(f"Send failed: {response.text}")
                    xbmc.executebuiltin('Notification(ERROR, Send to Telegram failed)')
            except Exception as e:
                logging.error(f"Send error: {e}")
                xbmc.executebuiltin('Notification(ERROR, Send to Telegram)')
        else:
            logging.info("No internet, log saved locally")
            xbmc.executebuiltin('Notification(Log CAN-Bus, Saved locally)')
    
    send()

except subprocess.TimeoutExpired:
    logging.error("candump timed out")
    xbmc.executebuiltin('Notification(ERROR, CAN dump timed out)')
except Exception as e:
    logging.error(f"Unexpected error: {e}")
    xbmc.executebuiltin('Notification(ERROR, Script failed)')
    sys.exit(1)
