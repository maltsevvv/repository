#!/usr/bin/env python
# -*- coding: utf-8 -*-
# addons/skin.rnspi/scripts/presstime.xml
import xbmc

rns_time_values = ["0.2", "0.4", "0.6", "0.8", "1"] 
rns_msg_values = ["2", "4", "6", "8", "10"]

def rns_time():
    current_value = xbmc.getInfoLabel("Skin.String(RNS_press_time)") or rns_time_values[0]
    try:
        current_index = rns_time_values.index(current_value)
        next_index = (current_index + 1) % len(rns_time_values)
        next_value = rns_time_values[next_index]
    except ValueError:
        next_value = rns_time_values[0]
    xbmc.executebuiltin(f'Skin.SetString(RNS_press_time, {next_value})')
    xbmc.executebuiltin(f'Notification(Time for Long Press Button, {next_value})')

def rns_msg():
    current_value = xbmc.getInfoLabel("Skin.String(RNS_press_messages)") or rns_msg_values[1]
    try:
        current_index = rns_msg_values.index(current_value)
        next_index = (current_index + 1) % len(rns_msg_values)
        next_value = rns_msg_values[next_index]
    except ValueError:
        next_value = rns_msg_values[0]
    xbmc.executebuiltin(f'Skin.SetString(RNS_press_messages, {next_value})')
    xbmc.executebuiltin(f'Notification(Number of messages for Long Press Button, {next_value})')

# Обработка аргументов для запуска конкретной функции
if __name__ == "__main__":
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower()  # Берем первый аргумент (игнорируем регистр)
        if arg == "rns_time":
            rns_time()
        elif arg == "rns_msg":
            rns_msg()
        else:
            # Если неизвестный аргумент, запускаем по умолчанию или покажем ошибку
            xbmc.executebuiltin('Notification(Неизвестная функция: {arg})')
            rns_time()  # Фоллбэк
    else:
        # Если аргумента нет (запуск всего скрипта), по умолчанию time
        rns_time()
        rns_msg()
