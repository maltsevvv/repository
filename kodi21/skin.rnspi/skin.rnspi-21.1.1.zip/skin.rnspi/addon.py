#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function
import xbmc
import xbmcaddon
import xbmcgui
import os
import subprocess
import threading
import shutil
import getpass

from time import sleep
from sendcan import sendcan
from bluetooth import a2dpinfo
from control import control
from threading import Thread, Timer
from config import update_states, emulation_canbus

# Глобальный Event для сигнала остановки (потокобезопасен, не требует global)
stop_event = threading.Event()

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')

user = getpass.getuser()

license_file = os.path.join(addon_path, 'License.txt')
license_file_pi = f'/home/{user}/License.txt'

if os.path.exists(license_file_pi) and not os.path.exists(license_file):
    try:
        shutil.copy(license_file_pi, license_file)
        xbmc.log(f"License.txt copied from /home/{user}/ to addon directory.", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Error copying License.txt: {e}", xbmc.LOGERROR)
if os.path.exists(license_file) and not os.path.exists(license_file_pi):
    try:
        shutil.copy(license_file, license_file_pi)
        #print("License.txt copied from addon directory to /home/pi/.")
        xbmc.log(f"License.txt copied from  addon directory to /home/{user}/.", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Error copying License.txt: {e}", xbmc.LOGERROR)

def rpi_temp():
    addon = xbmcaddon.Addon()
    while not stop_event.is_set():
        try:
            if os.path.exists('/sys/class/thermal/thermal_zone0/temp'):
                with open('/sys/class/thermal/thermal_zone0/temp', 'r') as tFile:
                    temp = float(tFile.read())
                    cpu_temp = round(temp / 1000)
                    if cpu_temp > 43.5:
                        xbmcgui.Window(10000).setProperty('rpi_cpu_temp', str(cpu_temp))
                    if cpu_temp > 65.5:
                        xbmc.log("RPi CPU temp: %s°C" % cpu_temp, 3)  # LOGWARNING
                    sleep(5)
            else:
                xbmc.log("Thermal zone file not found, skipping temp check", 3)  # LOGWARNING
                sleep(30)
        except Exception as e:
            xbmc.log("Error in rpi_temp: %s" % str(e), 4)  # LOGERROR
            break

def sd():
    addon = xbmcaddon.Addon()
    while not stop_event.is_set():
        try:
            cmd = "df -h | awk '$NF==\"/\"{printf $1}'"
            result = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
            if result in ['/dev/mmcblk0p2', '/dev/root']:
                xbmc.executebuiltin('Skin.SetString(sd,open)')
                xbmc.log("SD status: open", xbmc.LOGINFO)
            elif result in ['overlayroot', 'overlay']:
                xbmc.executebuiltin('Skin.SetString(sd,close)')
                xbmc.log("SD status: close", xbmc.LOGINFO)
            else:
                xbmc.log("Unknown SD mount: %s" % result, 3)  # LOGWARNING
        except subprocess.CalledProcessError as e:
            xbmc.log("Error running df command: %s" % str(e), 4)  # LOGERROR
        except Exception as e:
            xbmc.log("Error in sd(): %s" % str(e), 4)  # LOGERROR
        sleep(30)  # Проверять каждые 30 секунд

def run_thread_safe(func):
    """Обёртка для запуска функций в потоках с обработкой ошибок"""
    def wrapper():
        try:
            func()
        except Exception as e:
            xbmc.log("Thread error in %s: %s" % (func.__name__, str(e)), 4)  # LOGERROR
    return wrapper

if __name__ == '__main__':
    addon = xbmcaddon.Addon()
    xbmc.log("Starting addon service", 2)  # LOGNOTICE
    
    threads = [
        Thread(target=run_thread_safe(update_states)),
        Thread(target=run_thread_safe(sendcan)),
        Thread(target=run_thread_safe(a2dpinfo)),
        Thread(target=run_thread_safe(control)),
        Thread(target=run_thread_safe(rpi_temp)),
        Thread(target=run_thread_safe(sd))
    ]

    for t in threads:
        t.daemon = True
        t.start()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        sleep(1)
    
    stop_event.set()
    for t in threads:
        t.join(timeout=5)
    xbmc.log("Addon service stopped", 2)  # LOGNOTICE
