import os
import xbmc
import subprocess
import glob
import requests
import time
import base
import getpass

# --- Функция для чтения номера лицензии из файла ---
def read_license_number(file_path):
    """Считывает номер из файла и возвращает его. Возвращает пустую строку, если файл не найден."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            number = f.read().strip()
            return number
    except FileNotFoundError:
        xbmc.log(f"Файл лицензии не найден: {file_path}", xbmc.LOGWARNING)
        return ""
    except Exception as e:
        xbmc.log(f"Ошибка при чтении файла лицензии: {e}", xbmc.LOGWARNING)
        return ""

# --- Функция для отправки документа в Telegram ---
def send_telegram_document(file_path, bot_token, chat_id, caption=""):
    """Отправляет файл в Telegram."""
    if not os.path.exists(file_path):
        message = f"Ошибка: Файл '{file_path}' не найден."
        xbmc.log(message, xbmc.LOGWARNING)
        xbmc.executebuiltin(f'Notification(Telegram Error, {os.path.basename(file_path)} not found)')
        return False
        
    url = f'https://api.telegram.org/bot{bot_token}/sendDocument'
    try:
        with open(file_path, 'rb') as f:
            files_data = {'document': f}
            data = {'chat_id': chat_id, 'caption': caption}
            response = requests.post(url, files=files_data, data=data)
            if response.status_code == 200:
                message = f"Файл '{os.path.basename(file_path)}' успешно отправлен в Telegram."
                xbmc.log(message, xbmc.LOGINFO)
                xbmc.executebuiltin(f"Notification(Sent to Telegram, {os.path.basename(file_path)})")
                return True
            else:
                message = f"Ошибка отправки файла '{os.path.basename(file_path)}': {response.status_code} - {response.json()}"
                xbmc.log(message, xbmc.LOGWARNING)
                xbmc.executebuiltin(f"Notification(Telegram Error, {os.path.basename(file_path)})")
                return False
    except Exception as e:
        message = f"Ошибка при отправке файла '{os.path.basename(file_path)}': {e}"
        xbmc.log(message, xbmc.LOGWARNING)
        xbmc.executebuiltin(f"Notification(Telegram Error, Sending {os.path.basename(file_path)})")
        return False

# --- Параметры ---
user = getpass.getuser()

log_dir = f'/home/{user}/log'
kodi_log_path = f'/home/{user}/.kodi/temp/kodi.log'
license_file_path = f'/home/{user}/License.txt'

bot_token = base.BOT_TOKEN
chat_id = base.CHAT_ID

# --- Получаем номер из файла лицензии ---
license_number = read_license_number(license_file_path)
if license_number:
    caption_prefix = f"🔑 {license_number}\n"
    xbmc.log(f"Номер лицензии успешно прочитан: {license_number}", xbmc.LOGINFO)
else:
    caption_prefix = "🔑"
    xbmc.log("Не удалось получить номер лицензии, отправка без него.", xbmc.LOGWARNING)

# --- Создаём папку, если её нет ---
os.makedirs(log_dir, exist_ok=True)

# --- Запускаем candump ---
xbmc.executebuiltin('Notification(Log file, Creation started)')
try:
    subprocess.run(['candump', 'can0', '-n', '8000', '-l'], cwd=log_dir, check=True)
    xbmc.executebuiltin('Notification(Finish, Created file)')
    xbmc.log("candump logging finished successfully.", xbmc.LOGINFO)
except subprocess.CalledProcessError as e:
    xbmc.executebuiltin('Notification(Error, starting candump)')
    xbmc.log(f"Error starting candump: {e}", xbmc.LOGWARNING)
    exit(1)

# --- Ожидание для завершения записи файла ---
time.sleep(10)

# --- Отправка последнего лога CAN-Bus ---
files = glob.glob(os.path.join(log_dir, 'candump-*.log'))

if files:
    latest_file = max(files, key=os.path.getmtime)
    xbmc.log(f"Найден последний файл CAN-Bus: {latest_file}", xbmc.LOGINFO)
    caption_can = f"{caption_prefix}"
    send_telegram_document(latest_file, bot_token, chat_id, caption=caption_can)
else:
    message = "Ошибка: Файлы с шаблоном 'candump-*.log' не найдены."
    xbmc.log(message, xbmc.LOGWARNING)
    xbmc.executebuiltin('Notification(CAN Log Error, Files not found)')

# --- Отправка лога Kodi ---
xbmc.log(f"Попытка отправки лога Kodi: {kodi_log_path}", xbmc.LOGINFO)
caption_kodi = f"{caption_prefix}"
send_telegram_document(kodi_log_path, bot_token, chat_id, caption=caption_kodi)

























# ####################################################################################
# import os
# import xbmc
# import subprocess
# import glob
# import requests
# import time
# import config

# # --- Функция для отправки документа в Telegram ---
# def send_telegram_document(file_path, bot_token, chat_id, caption=""):
    # """Отправляет файл в Telegram."""
    # if not os.path.exists(file_path):
        # message = f"Ошибка: Файл '{file_path}' не найден."
        # xbmc.log(message, xbmc.LOGWARNING)
        # xbmc.executebuiltin(f'Notification(Telegram Error, {os.path.basename(file_path)} not found)')
        # return False
        
    # url = f'https://api.telegram.org/bot{bot_token}/sendDocument'
    # try:
        # with open(file_path, 'rb') as f:
            # files_data = {'document': f}
            # data = {'chat_id': chat_id, 'caption': caption}
            # response = requests.post(url, files=files_data, data=data)
            # if response.status_code == 200:
                # message = f"Файл '{os.path.basename(file_path)}' успешно отправлен в Telegram."
                # xbmc.log(message, xbmc.LOGINFO)
                # xbmc.executebuiltin(f"Notification(Sent to Telegram, {os.path.basename(file_path)})")
                # return True
            # else:
                # message = f"Ошибка отправки файла '{os.path.basename(file_path)}': {response.status_code} - {response.json()}"
                # xbmc.log(message, xbmc.LOGWARNING)
                # xbmc.executebuiltin(f"Notification(Telegram Error, {os.path.basename(file_path)})")
                # return False
    # except Exception as e:
        # message = f"Ошибка при отправке файла '{os.path.basename(file_path)}': {e}"
        # xbmc.log(message, xbmc.LOGWARNING)
        # xbmc.executebuiltin(f"Notification(Telegram Error, Sending {os.path.basename(file_path)})")
        # return False

# # --- Параметры ---
# log_dir = '/home/pi/log'
# kodi_log_path = '/home/pi/.kodi/temp/kodi.log'
# bot_token = config.BOT_TOKEN
# chat_id = config.CHAT_ID

# # --- Создаём папку, если её нет ---
# os.makedirs(log_dir, exist_ok=True)

# # --- Запускаем candump ---
# xbmc.executebuiltin('Notification(Log file, Creation started)')
# try:
    # subprocess.run(['candump', 'can0', '-n', '40', '-l'], cwd=log_dir, check=True)
    # xbmc.executebuiltin('Notification(Finish, Created file)')
    # xbmc.log("candump logging finished successfully.", xbmc.LOGINFO)
# except subprocess.CalledProcessError as e:
    # xbmc.executebuiltin('Notification(Error, starting candump)')
    # xbmc.log(f"Error starting candump: {e}", xbmc.LOGWARNING)
    # # Выходим из скрипта, так как без файла CAN-лога дальнейшие действия бессмысленны
    # exit(1)

# # --- Ожидание для завершения записи файла ---
# time.sleep(10)

# # --- Отправка последнего лога CAN-Bus ---
# files = glob.glob(os.path.join(log_dir, 'candump-*.log'))

# if files:
    # latest_file = max(files, key=os.path.getmtime)
    # xbmc.log(f"Найден последний файл CAN-Bus: {latest_file}", xbmc.LOGINFO)
    # send_telegram_document(latest_file, bot_token, chat_id, caption="Лог CAN-Bus")
# else:
    # message = "Ошибка: Файлы с шаблоном 'candump-*.log' не найдены."
    # xbmc.log(message, xbmc.LOGWARNING)
    # xbmc.executebuiltin(f"Notification(CAN Log Error, Files not found)")

# # --- Отправка лога Kodi ---
# xbmc.log(f"Попытка отправки лога Kodi: {kodi_log_path}", xbmc.LOGINFO)
# send_telegram_document(kodi_log_path, bot_token, chat_id, caption="Лог Kodi")

# ###################################################################################################

























# import os
# import xbmc
# import subprocess
# import glob
# import requests
# import config

# # Параметры (замени на свои!)
# log_dir = '/home/pi/log'
# bot_token = config.BOT_TOKEN # Получи от @BotFather
# chat_id = config.CHAT_ID      # ID чата или пользователя

# # Создаём папку, если её нет
# os.makedirs(log_dir, exist_ok=True)

# # Запускаем candump для логирования 40 пакетов в папку
# try:
    # xbmc.executebuiltin('Notification(Log file, creation started)')
    # subprocess.run(['candump', 'can0', '-n', '40', '-l'], cwd=log_dir, check=True)
    # #print("Логирование завершено!")
    # xbmc.executebuiltin(f"Notification(Finish, Created file)")
# except subprocess.CalledProcessError as e:
    # xbmc.executebuiltin(f"Notification(Error, starting candump:)")
    # xbmc.log(f"Error starting candump: {e}", level=xbmc.LOGWARNING)
    # # print(f"Ошибка при запуске candump: {e}")
    # exit(1)

# # Находим последний созданный файл (по времени модификации)
# files = glob.glob(os.path.join(log_dir, 'candump-*.log'))  # Ищем файлы вида can0-*.log
# if files:
    # latest_file = max(files, key=os.path.getmtime)
    # # print(f"Последний файл: {latest_file}")
    # # Перемещаем вызов xbmc.log внутрь этого блока
    # xbmc.log(f"Logging complete!, {latest_file}", xbmc.LOGINFO)
    # # Отправляем файл в Telegram
    # url = f'https://api.telegram.org/bot{bot_token}/sendDocument'
    # try:
        # with open(latest_file, 'rb') as f:
            # files_data = {'document': f}
            # data = {'chat_id': chat_id}
            # response = requests.post(url, files=files_data, data=data)
            # if response.status_code == 200:
                # # print("Файл успешно отправлен в Telegram!")
                # xbmc.executebuiltin(f"Notification(Sent to Telegram:, {latest_file})")
            # else:
                # # print(f"Ошибка отправки: {response.json()}")
                # # Также можно добавить лог в Kodi об отсутствии файла
                # xbmc.log("Error: CAN log files not found.", xbmc.LOGERROR)
                # xbmc.executebuiltin(f"Notification(CAN log files, Not found)")
    # except Exception as e:
        # #print(f"Ошибка при отправке файла: {e}")
        # xbmc.log(f"Error sending file:, {e}", level=xbmc.LOGWARNING)
# else:
    # print("Файлы не найдены в папке.")
    # xbmc.log(f"Not found log can bus file:, {e}", level=xbmc.LOGWARNING)
