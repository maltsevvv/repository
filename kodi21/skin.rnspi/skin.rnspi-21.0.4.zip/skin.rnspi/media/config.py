import xbmc
import xbmcgui
import os
import time

from bluetooth import bt_next, bt_prev, bt_disconnect

# Константы для CAN-команд (вынесены из основного скрипта для лучшей организации)
ENCODER_LEFT = '200100FF'
ENCODER_RIGHT = '200101FF'
ENCODER_PRESS = '20010005'
RETURN_CMD = '20010050'
MODE_CMD = '20010003'
UP_CMD = '20010200'
DOWN_CMD = '20012000'
LEFT_CMD = '20010100'
RIGHT_CMD = '20010300'
AS_CMD = '20010400'

# Глобальная переменная для кнопок RNSE
up_btn = 0
down_btn = 0
left_btn = 0
right_btn = 0
encoder_btn = 0
back_btn = 0
setup_btn = 0

# Глобальные переменные для кеширования состояний skin settings (все по умолчанию 'true')
encoder_change = 'false'
mfsw_horizontal = 'false'
mfsw_vertical = 'false'
send_to_fis = 'false'
emulation_canbus = 'false'
emulation_tmc = 'false'
emulation_rnsdtv = 'false'
emulation_rnsetv = 'false'
power_off = 'false'
tft_off = 'false'
keycar_out = 'false'
time_car = 'false'
rnsd_remote = 'false'
mfd_remote = 'false'
command_mb_remote = 'false'

def update_states():
    global encoder_change, mfsw_horizontal, mfsw_vertical, send_to_fis, emulation_canbus, emulation_tmc, emulation_rnsdtv, emulation_rnsetv, power_off, tft_off, keycar_out, time_car, rnsd_remote, mfd_remote, command_mb_remote
    # Переменные для предыдущих состояний
    last_encoder_change = encoder_change
    last_mfsw_horizontal = mfsw_horizontal
    last_mfsw_vertical = mfsw_vertical
    last_send_to_fis = send_to_fis
    last_emulation_canbus = emulation_canbus
    last_emulation_tmc = emulation_tmc
    last_emulation_rnsdtv = emulation_rnsdtv
    last_emulation_rnsetv = emulation_rnsetv
    last_power_off = power_off
    last_tft_off = tft_off
    last_keycar_out = keycar_out
    last_time_car = time_car
    last_rnsd_remote = rnsd_remote
    last_mfd_remote = mfd_remote
    last_command_mb_remote = command_mb_remote
    while True:
        # Проверка encoder_change
        current_encoder_change = 'true' if xbmc.getCondVisibility("Skin.HasSetting(encoder_change)") else 'false'
        if current_encoder_change != last_encoder_change:
            encoder_change = current_encoder_change
            xbmc.log(f"Skin.HasSetting(encoder_change) changed: {encoder_change}", level=xbmc.LOGWARNING)
            last_encoder_change = current_encoder_change
        
        # Проверка mfsw_horizontal
        current_mfsw_horizontal = 'true' if xbmc.getCondVisibility("Skin.HasSetting(mfsw_horizontal)") else 'false'
        if current_mfsw_horizontal != last_mfsw_horizontal:
            mfsw_horizontal = current_mfsw_horizontal
            xbmc.log(f"Skin.HasSetting(mfsw_horizontal) changed: {mfsw_horizontal}", level=xbmc.LOGWARNING)
            last_mfsw_horizontal = current_mfsw_horizontal
        
        # Проверка mfsw_vertical
        current_mfsw_vertical = 'true' if xbmc.getCondVisibility("Skin.HasSetting(mfsw_vertical)") else 'false'
        if current_mfsw_vertical != last_mfsw_vertical:
            mfsw_vertical = current_mfsw_vertical
            xbmc.log(f"Skin.HasSetting(mfsw_vertical) changed: {mfsw_vertical}", level=xbmc.LOGWARNING)
            last_mfsw_vertical = current_mfsw_vertical
        
        # Проверка send_to_fis
        current_send_to_fis = 'true' if xbmc.getCondVisibility("Skin.HasSetting(send_to_fis)") else 'false'
        if current_send_to_fis != last_send_to_fis:
            send_to_fis = current_send_to_fis
            xbmc.log(f"Skin.HasSetting(send_to_fis) changed: {send_to_fis}", level=xbmc.LOGWARNING)
            last_send_to_fis = current_send_to_fis
        
        # Проверка emulation_can_bus
        current_emulation_canbus = 'true' if xbmc.getCondVisibility("Skin.HasSetting(emulation_canbus)") else 'false'
        if current_emulation_canbus != last_emulation_canbus:
            emulation_canbus = current_emulation_canbus
            xbmc.log(f"Skin.HasSetting(emulation_canbus) changed: {emulation_canbus}", level=xbmc.LOGWARNING)
            last_emulation_canbus = current_emulation_canbus
            # Отправка для активации выполняется один раз при загрузки
            if emulation_canbus == 'true':
                os.system('cansend can0 271#10') # send_key_out
                time.sleep(2)
                os.system('cansend can0 271#07') # send_ign
                time.sleep(2)
                os.system('cansend can0 635#000000') # send_light_off
                time.sleep(2)
                os.system('cansend can0 635#006400') # send_light_on

        # Проверка emulation_tmc
        current_emulation_tmc = 'true' if xbmc.getCondVisibility("Skin.HasSetting(emulation_tmc)") else 'false'
        if current_emulation_tmc != last_emulation_tmc:
            emulation_tmc = current_emulation_tmc
            xbmc.log(f"Skin.HasSetting(emulation_tmc) changed: {emulation_tmc}", level=xbmc.LOGWARNING)
            last_emulation_tmc = current_emulation_tmc
            # Отправка для активации выполняется один раз при загрузки
            if emulation_tmc == 'true':
                os.system('cansend can0 418#E00F00')

        # Проверка emulation_rnsdtv
        current_emulation_rnsdtv = 'true' if xbmc.getCondVisibility("Skin.HasSetting(emulation_rnsdtv)") else 'false'
        if current_emulation_rnsdtv != last_emulation_rnsdtv:
            emulation_rnsdtv = current_emulation_rnsdtv
            xbmc.log(f"Skin.HasSetting(emulation_rnsdtv) changed: {emulation_rnsdtv}", level=xbmc.LOGWARNING)
            last_emulation_rnsdtv = current_emulation_rnsdtv
            # Отправка для активации выполняется один раз при загрузки
            if emulation_rnsdtv == 'true':
                os.system('cansend can0 464#E00100')
        
        # Проверка emulation_rnsetv
        current_emulation_rnsetv = 'true' if xbmc.getCondVisibility("Skin.HasSetting(emulation_rnsetv)") else 'false'
        if current_emulation_rnsetv != last_emulation_rnsetv:
            emulation_rnsetv = current_emulation_rnsetv
            xbmc.log(f"Skin.HasSetting(emulation_rnsetv) changed: {emulation_rnsetv}", level=xbmc.LOGWARNING)
            last_emulation_rnsetv = current_emulation_rnsetv
        
        # Проверка power_off
        current_power_off = 'true' if xbmc.getCondVisibility("Skin.HasSetting(power_off)") else 'false'
        if current_power_off != last_power_off:
            power_off = current_power_off
            xbmc.log(f"Skin.HasSetting(power_off) changed: {power_off}", level=xbmc.LOGWARNING)
            last_power_off = current_power_off
        
        # Проверка tft_off
        current_tft_off = 'true' if xbmc.getCondVisibility("Skin.HasSetting(tft_off)") else 'false'
        if current_tft_off != last_tft_off:
            tft_off = current_tft_off
            xbmc.log(f"Skin.HasSetting(tft_off) changed: {tft_off}", level=xbmc.LOGWARNING)
            last_tft_off = current_tft_off
        
        # Проверка keycar_out
        current_keycar_out = 'true' if xbmc.getCondVisibility("Skin.HasSetting(keycar_out)") else 'false'
        if current_keycar_out != last_keycar_out:
            keycar_out = current_keycar_out
            xbmc.log(f"Skin.HasSetting(keycar_out) changed: {keycar_out}", level=xbmc.LOGWARNING)
            last_keycar_out = current_keycar_out
        
        # Проверка time_car
        current_time_car = 'true' if xbmc.getCondVisibility("Skin.HasSetting(CanBusTime)") else 'false'
        if current_time_car != last_time_car:
            time_car = current_time_car
            xbmc.log(f"Skin.HasSetting(CanBusTime) changed: {time_car}", level=xbmc.LOGWARNING)
            last_time_car = current_time_car
        
        # Проверка rnsd_remote
        current_rnsd_remote = 'true' if xbmc.getCondVisibility("Skin.HasSetting(rnsd_remote)") else 'false'
        if current_rnsd_remote != last_rnsd_remote:
            rnsd_remote = current_rnsd_remote
            xbmc.log(f"Skin.HasSetting(rnsd_remote) changed: {rnsd_remote}", level=xbmc.LOGWARNING)
            last_rnsd_remote = current_rnsd_remote
        
        # Проверка mfd_remote
        current_mfd_remote = 'true' if xbmc.getCondVisibility("Skin.HasSetting(mfd_remote)") else 'false'
        if current_mfd_remote != last_mfd_remote:
            mfd_remote = current_mfd_remote
            xbmc.log(f"Skin.HasSetting(mfd_remote) changed: {mfd_remote}", level=xbmc.LOGWARNING)
            last_mfd_remote = current_mfd_remote
        
        # Проверка command_mb_remote
        current_command_mb_remote = 'true' if xbmc.getCondVisibility("Skin.HasSetting(command_mb_remote)") else 'false'
        if current_command_mb_remote != last_command_mb_remote:
            command_mb_remote = current_command_mb_remote
            xbmc.log(f"Skin.HasSetting(command_mb_remote) changed: {command_mb_remote}", level=xbmc.LOGWARNING)
            last_command_mb_remote = current_command_mb_remote
            
            
        time.sleep(2)  # Задержка 0.5 секунды перед следующей итерацией    

def get_property():
    """
    Получает свойства из Kodi Window(10000) и возвращает их в виде словаря.
    Это позволяет легко добавить новые свойства или изменить логику получения.
    """
    properties = {
        'BT_CONNECT': xbmcgui.Window(10000).getProperty('BTConnect'),
        'VIDEO_OSD_ACTIVE': xbmc.getCondVisibility('Window.IsActive(videoosd)'),
        'MUSIC_OSD_ACTIVE': xbmc.getCondVisibility('Window.IsActive(musicosd)'),
        'WINDOW_HOME': xbmc.getCondVisibility('Window.IsActive(Home)'),
        'WINDOW_MENU': xbmc.getCondVisibility('Window.IsActive(1100)'),
        'WINDOW_SD': xbmc.getCondVisibility('Window.IsActive(1102)'),
        'WINDOW_POWER': xbmc.getCondVisibility('Window.IsActive(shutdownmenu)'),
        'WINDOW_DASHBOARD': xbmc.getCondVisibility('Window.IsActive(Visualisation)')
    }
    return properties


def encoder_left():
    window_menu = xbmc.getCondVisibility('Window.IsActive(1100)')  # Используем свойства
    window_sd = xbmc.getCondVisibility('Window.IsActive(1102)')  # Используем свойства
    window_power = xbmc.getCondVisibility('Window.IsActive(shutdownmenu)')  # Используем свойства
    if encoder_change == 'true':
        if window_menu or window_sd or window_power:
            xbmc.executebuiltin('Action(Left)')
        else:
            xbmc.executebuiltin('Action(Down)')
    else:
        if window_menu or window_sd or window_power:
            xbmc.executebuiltin('Action(Left)')
        else:
            xbmc.executebuiltin('Action(Up)')

def encoder_right():
    window_menu = xbmc.getCondVisibility('Window.IsActive(1100)')  # Используем свойства
    window_sd = xbmc.getCondVisibility('Window.IsActive(1102)')  # Используем свойства
    window_power = xbmc.getCondVisibility('Window.IsActive(shutdownmenu)')  # Используем свойства
    if encoder_change == 'true':
        if window_menu or window_sd or window_power:
            xbmc.executebuiltin('Action(Right)')
        else:
            xbmc.executebuiltin('Action(Up)')
    else:
        if window_menu or window_sd or window_power:
            xbmc.executebuiltin('Action(Right)')
        else:
            xbmc.executebuiltin('Action(Down)')

def rns_setup():
    if xbmc.getCondVisibility('Player.HasMedia'):
        xbmc.executebuiltin('Action(OSD)')
        return
    else:
        xbmc.executebuiltin('Action(ContextMenu)')
        return

def rns_tft():
    if tft_off == 'true':
        if power_off == 'true':
            os.system('sudo poweroff &')
        else:
            os.system('sudo reboot &')

def mfsw_up(): # 🔼
    properties = get_property()  # Получаем свойства здесь
    bt_connect = properties.get('BT_CONNECT')  # Используем свойства
    window_home = properties.get('WINDOW_HOME')
    window_dashboard = properties.get('WINDOW_DASHBOARD')
    if mfsw_vertical == 'true':
        if (bt_connect and window_home) or (bt_connect and window_dashboard):
            bt_next()
        if xbmc.getCondVisibility('Player.HasMedia'):
            xbmc.executebuiltin('PlayerControl(Previous)')
        else:
            if not bt_connect:
                xbmc.executebuiltin('Action(Up)')
    else:
        if (bt_connect and window_home) or (bt_connect and window_dashboard):
            bt_next()
        if xbmc.getCondVisibility('Player.HasMedia'):
            xbmc.executebuiltin('PlayerControl(Next)')
        else:
            if not bt_connect:
                xbmc.executebuiltin('Action(Up)')

def mfsw_down(): # 🔽
    properties = get_property()  # Получаем свойства здесь
    bt_connect = properties.get('BT_CONNECT')  # Используем свойства
    window_home = properties.get('WINDOW_HOME')
    window_dashboard = properties.get('WINDOW_DASHBOARD')

    if mfsw_vertical == 'true':
        if (bt_connect and window_home) or (bt_connect and window_dashboard):
            bt_next()
        if xbmc.getCondVisibility('Player.HasMedia'):
            xbmc.executebuiltin('PlayerControl(Previous)')
        else:
            if not bt_connect:
                xbmc.executebuiltin('Action(Down)')
    else:
        if (bt_connect and window_home) or (bt_connect and window_dashboard):
            bt_next()
        if xbmc.getCondVisibility('Player.HasMedia'):
            xbmc.executebuiltin('PlayerControl(Next)')
        else:
            if not bt_connect:
                xbmc.executebuiltin('Action(Down)')

def mfsw_left(): # ◀
    if mfsw_horizontal == 'true':
        xbmc.executebuiltin('Action(Select)')
    else:
        xbmc.executebuiltin('Action(Back)')

def mfsw_right(): # ▶
    if mfsw_horizontal == 'true':
        xbmc.executebuiltin('Action(Back)')
    else:
        xbmc.executebuiltin('Action(Select)')

def mfsw_fis_left(): # msg == 3A05 ◀
    properties = get_property()  # Получаем свойства здесь
    bt_connect = properties.get('BT_CONNECT')  # Используем свойства
    window_home = properties.get('WINDOW_HOME')
    window_dashboard = properties.get('WINDOW_DASHBOARD')
    if mfsw_horizontal:
        if (bt_connect and window_home) or (bt_connect and window_dashboard):
            bt_prev()
        if xbmc.getCondVisibility('Player.HasMedia'):
            xbmc.executebuiltin('PlayerControl(Previous)')
        else:
            if not bt_connect:
                xbmc.executebuiltin('Action(Select)')
    else:
        if (bt_connect and window_home) or (bt_connect and window_dashboard):
            bt_prev()
        if xbmc.getCondVisibility('Player.HasMedia'):
            xbmc.executebuiltin('PlayerControl(Previous)')
        else:
            if not bt_connect:
                xbmc.executebuiltin('Action(Back)')    
    
def mfsw_fis_right(): # msg == 3A04 ▶
    properties = get_property()  # Получаем свойства здесь
    bt_connect = properties.get('BT_CONNECT')  # Используем свойства
    window_home = properties.get('WINDOW_HOME')
    window_dashboard = properties.get('WINDOW_DASHBOARD')
    if mfsw_horizontal == 'true':
        if (bt_connect and window_home) or (bt_connect and window_dashboard):
            bt_next()
        if xbmc.getCondVisibility('Player.HasMedia'):
            xbmc.executebuiltin('PlayerControl(Next)')
        else:
            if not bt_connect:
                xbmc.executebuiltin('Action(Back)')
    else:
        if (bt_connect and window_home) or (bt_connect and window_dashboard):
            bt_next()
        if xbmc.getCondVisibility('Player.HasMedia'):
            xbmc.executebuiltin('PlayerControl(Next)')
        else:
            if not bt_connect:
                xbmc.executebuiltin('Action(Select)')

def canbus_keycar(): # Monitoring the state change key car 🔑
    if keycar_out == 'true':
        os.system('sudo poweroff &' if power_off == 'true' else 'sudo reboot &')
