#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcgui
import re

data_file = '/home/pi/carservice.txt'
#data_file = r'C:\Users\Malts\AppData\Roaming\Kodi\addons\skin.rnspi\carservice.txt'
def convert_for_kodi(text):
    """Конвертирует текст из UTF-8 в CP1251 для корректного отображения в Kodi"""
    try:
        if isinstance(text, str):
            return text.encode('cp1251', errors='replace').decode('cp1251', errors='replace')
        return text
    except:
        return str(text)  # Fallback, если конвертация не удалась

def format_date_input(user_input):
    if re.match(r'\d{2}\.\d{2}\.\d{4}', user_input):
        return user_input
    if re.match(r'\d{8}', user_input):
        return f"{user_input[:2]}.{user_input[2:4]}.{user_input[4:]}"
    return user_input

def load_car_data():
    if not os.path.exists(data_file):
        default_lines = [
            "NAME | DATA | CAR KM | MAX | NEXT KM",
            "Ремень ГРМ | 20.12.2020 | 125000 | 8000 | 133000",
            "Масло | 20.12.2020 | 125000 | 10000 | 135000"
        ]
        with open(data_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(default_lines) + '\n')
        return [
            {"name": "Ремень ГРМ", "data": "20.12.2020", "car_km": 125000, "max": 8000, "next_km": 133000},
            {"name": "Масло", "data": "20.12.2020", "car_km": 125000, "max": 10000, "next_km": 135000}
        ]

    try:
        with open(data_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except UnicodeDecodeError:
        with open(data_file, 'r', encoding='cp1251') as f:
            content = f.read()

    lines = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("NAME |"):
            continue
        parts = [p.strip() for p in line.split(' | ')]
        if len(parts) == 5:
            try:
                lines.append({
                    "name": parts[0],
                    "data": parts[1],
                    "car_km": int(parts[2]),
                    "max": int(parts[3]),
                    "next_km": int(parts[4])
                })
            except ValueError:
                continue
    return lines

def save_car_data(data_list):
    try:
        lines = ["NAME | DATA | CAR KM | MAX | NEXT KM"]
        for item in data_list:
            line = f"{item['name']} | {item['data']} | {item['car_km']} | {item['max']} | {item['next_km']}"
            lines.append(line)
        with open(data_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
    except Exception as e:
        xbmc.log(f"Ошибка сохранения: {str(e)}", xbmc.LOGERROR)

def calculate_next_km(car_km, max_val):
    return car_km + max_val

def main_menu():
    dialog = xbmcgui.Dialog()

    while True:
        data_list = load_car_data()

        # Конвертируем текст для отображения в Kodi
        options = [
            f"{convert_for_kodi(item['name'])} | {item['data']} | {item['car_km']} | {item['max']} | {item['next_km']}"
            for item in data_list
        ]
        options.append(convert_for_kodi("Добавить новую запись"))
        options.append(convert_for_kodi("Выход"))

        choice = dialog.select(convert_for_kodi("Регламент обслуживания автомобиля"), options)

        if choice == -1 or choice == len(options) - 1:  # Выход
            break
        elif choice == len(options) - 2:  # Добавить новую запись
            name = dialog.input(convert_for_kodi("Введите название запчасти (NAME)"), type=xbmcgui.INPUT_ALPHANUM)
            if not name:
                continue
            data = dialog.input(convert_for_kodi("Введите дату (DATA, формат DD.MM.YYYY)"), '', type=xbmcgui.INPUT_DATE)
            if not data:
                data = dialog.input(convert_for_kodi("Введите дату цифрами (DDMMYYYY)"), type=xbmcgui.INPUT_NUMERIC)
                if data:
                    data = format_date_input(data)
                else:
                    continue
            car_km_str = dialog.numeric(0, convert_for_kodi("Введите текущий пробег (CAR KM)"), "0")
            if not car_km_str:
                continue
            try:
                car_km = int(car_km_str)
            except ValueError:
                dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число для CAR KM!"))
                continue
            max_str = dialog.numeric(0, convert_for_kodi("Введите интервал (MAX, км)"), "10000")
            if not max_str:
                continue
            try:
                max_val = int(max_str)
            except ValueError:
                dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число для MAX!"))
                continue
            next_km = calculate_next_km(car_km, max_val)
            data_list.append({"name": name, "data": data, "car_km": car_km, "max": max_val, "next_km": next_km})
            save_car_data(data_list)
            dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi(f"Запись добавлена: {name}"))
        else:  # Редактировать запись
            item = data_list[choice]
            edit_choice = dialog.select(
                convert_for_kodi(f"Редактировать: {item['name']}"),
                [
                    f"{convert_for_kodi('NAME')}: {convert_for_kodi(item['name'])}",
                    f"{convert_for_kodi('DATA')}: {item['data']}",
                    f"{convert_for_kodi('CAR KM')}: {item['car_km']}",
                    f"{convert_for_kodi('MAX')}: {item['max']}",
                    f"{convert_for_kodi('NEXT KM')}: {item['next_km']} ({convert_for_kodi('только просмотр')})"
                ]
            )
            if edit_choice == 0:  # NAME
                new_name = dialog.input(convert_for_kodi("Введите новое название (NAME)"), convert_for_kodi(item['name']), type=xbmcgui.INPUT_ALPHANUM)
                if new_name:
                    item['name'] = new_name
                    save_car_data(data_list)
                    dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi("NAME обновлён"))
            elif edit_choice == 1:  # DATA
                new_data = dialog.input(convert_for_kodi("Введите новую дату (DATA)"), item['data'], type=xbmcgui.INPUT_DATE)
                if not new_data:
                    new_data = dialog.input(convert_for_kodi("Введите дату цифрами (DDMMYYYY)"), item['data'].replace('.', ''), type=xbmcgui.INPUT_NUMERIC)
                    if new_data:
                        new_data = format_date_input(new_data)
                    else:
                        new_data = item['data']
                if new_data != item['data']:
                    item['data'] = new_data
                    save_car_data(data_list)
                    dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi("DATA обновлён"))
            elif edit_choice == 2:  # CAR KM
                new_car_km_str = dialog.numeric(0, convert_for_kodi("Введите новый пробег (CAR KM)"), str(item['car_km']))
                if new_car_km_str:
                    try:
                        item['car_km'] = int(new_car_km_str)
                        item['next_km'] = calculate_next_km(item['car_km'], item['max'])
                        save_car_data(data_list)
                        dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi(f"CAR KM и NEXT KM обновлены: {item['next_km']}"))
                    except ValueError:
                        dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число!"))
            elif edit_choice == 3:  # MAX
                new_max_str = dialog.numeric(0, convert_for_kodi("Введите новый интервал (MAX)"), str(item['max']))
                if new_max_str:
                    try:
                        item['max'] = int(new_max_str)
                        item['next_km'] = calculate_next_km(item['car_km'], item['max'])
                        save_car_data(data_list)
                        dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi(f"MAX и NEXT KM обновлены: {item['next_km']}"))
                    except ValueError:
                        dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число!"))

if __name__ == '__main__':
    main_menu()






# #!/usr/bin/env python
# # -*- coding: utf-8 -*-
# import os
# import xbmc
# import xbmcgui
# import re  # Для fallback-форматирования даты, если нужно

# #data_file = '/home/pi/.kodi/carservice.txt'
# data_file = r'C:\Users\Malts\AppData\Roaming\Kodi\addons\skin.rnspi\carservice.txt'
# def format_date_input(user_input):
    # """Fallback: форматирует ввод цифр в DD.MM.YYYY (если INPUT_DATE не сработает)"""
    # # Если ввод уже с разделителями, возвращаем как есть
    # if re.match(r'\d{2}\.\d{2}\.\d{4}', user_input):
        # return user_input
    # # Если чистые цифры (8 символов: DDMMYYYY)
    # if re.match(r'\d{8}', user_input):
        # return f"{user_input[:2]}.{user_input[2:4]}.{user_input[4:]}"
    # return user_input  # Иначе как есть

# def load_car_data():
    # """Загружает данные из файла: список словарей для строк, с обработкой кодировки"""
    # if not os.path.exists(data_file):
        # # Создаём файл с заголовком и дефолтными строками (дата исправлена на 20.12.2020)
        # default_lines = [
            # "NAME | DATA | CAR KM | MAX | NEXT KM",
            # "Ремень ГРМ | 20.12.2020 | 125000 | 8000 | 133000",
            # "Масло | 20.12.2020 | 125000 | 10000 | 135000"
        # ]
        # with open(data_file, 'w', encoding='utf-8') as f:
            # f.write('\n'.join(default_lines) + '\n')
        # return [
            # {"name": "Ремень ГРМ", "data": "20.12.2020", "car_km": 125000, "max": 8000, "next_km": 133000},
            # {"name": "Масло", "data": "20.12.2020", "car_km": 125000, "max": 10000, "next_km": 135000}
        # ]
    
    # lines = []
    # try:
        # # Сначала пробуем читать как UTF-8
        # with open(data_file, 'r', encoding='utf-8', errors='ignore') as f:
            # content = f.read()
        # # Если контент пустой или с ошибками, пробуем CP1251
        # if not content.strip() or '' in content:  #  — маркер ошибок декодирования
            # with open(data_file, 'r', encoding='cp1251', errors='ignore') as f:
                # content = f.read()
    # except Exception as e:
        # xbmc.log(f"Ошибка чтения файла: {str(e)}", xbmc.LOGERROR)
        # return []
    
    # for line in content.splitlines():
        # line = line.strip()
        # if not line or line == "NAME | DATA | CAR KM | MAX | NEXT KM":
            # continue  # Пропускаем заголовок и пустые
        # parts = [p.strip() for p in line.split(' | ')]
        # if len(parts) == 5:
            # try:
                # lines.append({
                    # "name": parts[0],
                    # "data": parts[1],
                    # "car_km": int(parts[2]),
                    # "max": int(parts[3]),
                    # "next_km": int(parts[4])
                # })
            # except ValueError:
                # continue  # Пропускаем некорректные строки
    
    # return lines

# def save_car_data(data_list):
    # """Сохраняет данные в файл в UTF-8"""
    # try:
        # lines = ["NAME | DATA | CAR KM | MAX | NEXT KM"]
        # for item in data_list:
            # line = f"{item['name']} | {item['data']} | {item['car_km']} | {item['max']} | {item['next_km']}"
            # lines.append(line)
        # with open(data_file, 'w', encoding='utf-8') as f:
            # f.write('\n'.join(lines) + '\n')
        # xbmc.log("Данные сохранены в UTF-8", xbmc.LOGINFO)
    # except Exception as e:
        # xbmc.log(f"Ошибка сохранения: {str(e)}", xbmc.LOGERROR)

# def calculate_next_km(car_km, max_val):
    # """Формула: NEXT KM = CAR KM + MAX (целые числа)"""
    # return car_km + max_val

# def main_menu():
    # """Главное меню с диалогами Kodi"""
    # dialog = xbmcgui.Dialog()
    
    # while True:
        # data_list = load_car_data()
        
        # # Создаём список для отображения (каждая строка как опция)
        # options = [f"{item['name']} | {item['data']} | {item['car_km']} | {item['max']} | {item['next_km']}" for item in data_list]
        # options.append("Добавить новую запись")
        # options.append("Выход")
        
        # choice = dialog.select("Регламент обслуживания автомобиля", options)
        
        # if choice == -1 or choice == len(options) - 1:  # Выход
            # break
        # elif choice == len(options) - 2:  # Добавить новую запись
            # # Ввод данных через диалоги
            # name = dialog.input("Введите название запчасти (NAME)", type=xbmcgui.INPUT_ALPHANUM)
            # if not name:
                # continue
            # # Для даты: INPUT_DATE для удобного ввода (цифры + разделители) — пустое поле по умолчанию
            # data = dialog.input("Введите дату (DATA, формат DD.MM.YYYY)", '', type=xbmcgui.INPUT_DATE)
            # if not data:
                # # Fallback на numeric, если INPUT_DATE не поддерживается
                # data = dialog.input("Введите дату цифрами (DDMMYYYY)", type=xbmcgui.INPUT_NUMERIC)
                # if data:
                    # data = format_date_input(data)
                # else:
                    # continue
            # car_km_str = dialog.numeric(0, "Введите текущий пробег (CAR KM)", "0")
            # if not car_km_str:
                # continue
            # try:
                # car_km = int(car_km_str)
            # except ValueError:
                # dialog.ok("Ошибка", "Введите корректное число для CAR KM!")
                # continue
            # max_str = dialog.numeric(0, "Введите интервал (MAX, км)", "10000")
            # if not max_str:
                # continue
            # try:
                # max_val = int(max_str)
            # except ValueError:
                # dialog.ok("Ошибка", "Введите корректное число для MAX!")
                # continue
            # next_km = calculate_next_km(car_km, max_val)
            # # Добавляем в список и сохраняем сразу
            # data_list.append({"name": name, "data": data, "car_km": car_km, "max": max_val, "next_km": next_km})
            # save_car_data(data_list)
            # dialog.ok("Успешно", f"Запись добавлена и сохранена: {name}")
        # else:  # Редактировать выбранную строку
            # item = data_list[choice]
            # # Показываем текущие данные и предлагаем редактировать
            # edit_choice = dialog.select(f"Редактировать: {item['name']}", [
                # f"NAME: {item['name']}",
                # f"DATA: {item['data']}",
                # f"CAR KM: {item['car_km']}",
                # f"MAX: {item['max']}",
                # f"NEXT KM: {item['next_km']} (только просмотр, рассчитывается автоматически)"
            # ])
            # if edit_choice == 0:  # NAME
                # new_name = dialog.input("Введите новое название (NAME)", item['name'], type=xbmcgui.INPUT_ALPHANUM)
                # if new_name:
                    # item['name'] = new_name
                    # save_car_data(data_list)  # Сохраняем сразу
                    # dialog.ok("Успешно", "NAME обновлён и сохранён")
            # elif edit_choice == 1:  # DATA
                # # Для даты: INPUT_DATE для удобного ввода (цифры + разделители)
                # new_data = dialog.input("Введите новую дату (DATA, формат DD.MM.YYYY)", item['data'], type=xbmcgui.INPUT_DATE)
                # if not new_data:
                    # # Fallback на numeric, если INPUT_DATE не поддерживается
                    # new_data = dialog.input("Введите дату цифрами (DDMMYYYY)", item['data'].replace('.', ''), type=xbmcgui.INPUT_NUMERIC)
                    # if new_data:
                        # new_data = format_date_input(new_data)
                    # else:
                        # new_data = item['data']  # Оставляем старое
                # if new_data != item['data']:  # Если изменилось
                    # item['data'] = new_data
                    # save_car_data(data_list)  # Сохраняем сразу
                    # dialog.ok("Успешно", "DATA обновлён и сохранён")
            # elif edit_choice == 2:  # CAR KM
                # new_car_km_str = dialog.numeric(0, "Введите новый текущий пробег (CAR KM)", str(item['car_km']))
                # if new_car_km_str:
                    # try:
                        # item['car_km'] = int(new_car_km_str)
                        # item['next_km'] = calculate_next_km(item['car_km'], item['max'])  # Пересчитываем
                        # save_car_data(data_list)  # Сохраняем сразу
                        # dialog.ok("Успешно", f"CAR KM и NEXT KM обновлены и сохранены: {item['next_km']}")
                    # except ValueError:
                        # dialog.ok("Ошибка", "Введите корректное число!")
            # elif edit_choice == 3:  # MAX
                # new_max_str = dialog.numeric(0, "Введите новый интервал (MAX)", str(item['max']))
                # if new_max_str:
                    # try:
                        # item['max'] = int(new_max_str)
                        # item['next_km'] = calculate_next_km(item['car_km'], item['max'])  # Пересчитываем
                        # save_car_data(data_list)  # Сохраняем сразу
                        # dialog.ok("Успешно", f"MAX и NEXT KM обновлены и сохранены: {item['next_km']}")
                    # except ValueError:
                        # dialog.ok("Ошибка", "Введите корректное число!")
            # elif edit_choice == 4:  # NEXT KM (только просмотр)
                # dialog.ok("Информация", f"NEXT KM рассчитывается автоматически: {item['next_km']}")

# if __name__ == '__main__':
    # main_menu()