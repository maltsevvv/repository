#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcgui
import xbmcvfs  # Добавь этот импорт для translatePath
import re

#data_file = r'C:\Users\Malts\AppData\Roaming\Kodi\addons\skin.rnspi\carservice.txt'
data_file = '/home/pi/carservice.txt'

def convert_for_kodi(text):
    """Конвертирует текст из UTF-8 в CP1251 для корректного отображения в Kodi"""
    try:
        if isinstance(text, str):
            return text.encode('cp1251', errors='replace').decode('cp1251', errors='replace')
        return text
    except:
        return str(text)  # Fallback, если конвертация не удалась

def format_date_input(user_input):
    if re.match(r'\d{2}\.\d{2}\.\d{4}', user_input):
        return user_input
    if re.match(r'\d{8}', user_input):
        return f"{user_input[:2]}.{user_input[2:4]}.{user_input[4:]}"
    return user_input

def load_car_data():
    if not os.path.exists(data_file):
        # Изменено: дефолтные строки в новом формате
        default_lines = [
            "NAME (DATA) CAR KM + MAX = NEXT KM",  # Заголовок без лишних пробелов
            "Ремень ГРМ (20.12.2020) 125000 + 8000 = 133000",
            "Масло (20.12.2020) 125000 + 10000 = 135000"
        ]
        with open(data_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(default_lines) + '\n')
        return [
            {"name": "Ремень ГРМ", "data": "20.12.2020", "car_km": 125000, "max": 8000, "next_km": 133000},
            {"name": "Масло", "data": "20.12.2020", "car_km": 125000, "max": 10000, "next_km": 135000}
        ]

    try:
        with open(data_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except UnicodeDecodeError:
        with open(data_file, 'r', encoding='cp1251') as f:
            content = f.read()

    lines = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("NAME ("):  # Пропускаем заголовок
            continue
        
        # Новое: парсинг с помощью regex для формата "NAME (DATA) CAR KM + MAX = NEXT KM"
        # Пример: "Ремень ГРМ (20.12.2020) 125000 + 8000 = 133000"
        match = re.match(r'(.+?)\s*\(\s*([^)]+)\)\s*(\d+)\s*\+\s*(\d+)\s*=\s*(\d+)', line)
        if match:
            try:
                name = match.group(1).strip()
                data = match.group(2).strip()
                car_km = int(match.group(3))
                max_val = int(match.group(4))
                next_km = int(match.group(5))
                lines.append({
                    "name": name,
                    "data": data,
                    "car_km": car_km,
                    "max": max_val,
                    "next_km": next_km
                })
            except ValueError:
                continue  # Пропускаем некорректные строки
    return lines

def save_car_data(data_list):
    try:
        # Изменено: заголовок без лишних пробелов, формат строк как в примере
        lines = ["NAME (DATA) CAR KM + MAX = NEXT KM"]
        for item in data_list:
            line = f"{item['name']} ({item['data']}) {item['car_km']} + {item['max']} = {item['next_km']}"
            lines.append(line)
        with open(data_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
    except Exception as e:
        xbmc.log(f"Ошибка сохранения: {str(e)}", xbmc.LOGERROR)

def calculate_next_km(car_km, max_val):
    return car_km + max_val

class CarServiceDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        super().__init__(xmlFilename, scriptPath, defaultSkin, defaultRes)
        self.data_list = []
        self.list_control = None  # Предполагаем, что в XML есть listcontrol с id=100

    def onInit(self):
        # Устанавливаем свойство при инициализации окна (после загрузки XML)
        self.setProperty('CustomDialogOpen', 'true')
        xbmc.log('Свойство CustomDialogOpen установлено: true', xbmc.LOGINFO)
        
        self.data_list = load_car_data()
        self.list_control = self.getControl(100)  # ID списка в XML, предположим 100
        if self.list_control is not None:
            self.update_list()
        else:
            xbmc.log('Ошибка: list_control (ID=100) не найден в XML!', xbmc.LOGERROR)

    def update_list(self):
        if self.list_control is None:
            return
        self.list_control.reset()
        for item in self.data_list:
            list_item = xbmcgui.ListItem(label=f"{convert_for_kodi(item['name'])} | {item['data']} | {item['car_km']} | {item['max']} | {item['next_km']}")
            list_item.setProperty('name', item['name'])
            list_item.setProperty('data', item['data'])
            list_item.setProperty('car_km', str(item['car_km']))
            list_item.setProperty('max', str(item['max']))
            list_item.setProperty('next_km', str(item['next_km']))
            self.list_control.addItem(list_item)

    def onAction(self, action):
        # Обработчик действий (например, закрытие по ESC или назад)
        if action.getId() in [xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:  # ESC или назад
            # Очищаем свойство при закрытии
            self.clearProperty('CustomDialogOpen')
            xbmc.log('Свойство CustomDialogOpen очищено (onAction)', xbmc.LOGINFO)
            self.close()

    def onClick(self, controlID):
        if controlID == 100:  # Клик на списке
            if self.list_control is not None:
                selected_index = self.list_control.getSelectedPosition()
                if selected_index >= 0:
                    self.edit_item(selected_index)
        elif controlID == 200:  # Предполагаем кнопку "Добавить новую запись" с id=200
            self.add_new_item()
        elif controlID == 300:  # Предполагаем кнопку "Выход" с id=300
            # Очищаем свойство при закрытии
            self.clearProperty('CustomDialogOpen')
            xbmc.log('Свойство CustomDialogOpen очищено (onClick)', xbmc.LOGINFO)
            self.close()

    def add_new_item(self):
        dialog = xbmcgui.Dialog()
        name = dialog.input(convert_for_kodi("Введите название запчасти (NAME)"), type=xbmcgui.INPUT_ALPHANUM)
        if not name:
            return
        data = dialog.input(convert_for_kodi("Введите дату (DATA, формат DD.MM.YYYY)"), '', type=xbmcgui.INPUT_DATE)
        if not data:
            data = dialog.input(convert_for_kodi("Введите дату цифрами (DDMMYYYY)"), type=xbmcgui.INPUT_NUMERIC)
            if data:
                data = format_date_input(data)
            else:
                return
        car_km_str = dialog.numeric(0, convert_for_kodi("Введите текущий пробег (CAR KM)"), "0")
        if not car_km_str:
            return
        try:
            car_km = int(car_km_str)
        except ValueError:
            dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число для CAR KM!"))
            return
        max_str = dialog.numeric(0, convert_for_kodi("Введите интервал (MAX, км)"), "10000")
        if not max_str:
            return
        try:
            max_val = int(max_str)
        except ValueError:
            dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число для MAX!"))
            return
        next_km = calculate_next_km(car_km, max_val)
        self.data_list.append({"name": name, "data": data, "car_km": car_km, "max": max_val, "next_km": next_km})
        save_car_data(self.data_list)
        self.update_list()
        dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi(f"Запись добавлена: {name}"))

    def edit_item(self, index):
        item = self.data_list[index]
        dialog = xbmcgui.Dialog()
        edit_choice = dialog.select(
            convert_for_kodi(f"Редактировать: {item['name']}"),
            [
                f"{convert_for_kodi('NAME')}: {convert_for_kodi(item['name'])}",
                f"{convert_for_kodi('DATA')}: {item['data']}",
                f"{convert_for_kodi('CAR KM')}: {item['car_km']}",
                f"{convert_for_kodi('MAX')}: {item['max']}",
                f"{convert_for_kodi('NEXT KM')}: {item['next_km']} ({convert_for_kodi('только просмотр')})"
            ]
        )
        if edit_choice == 0:  # NAME
            new_name = dialog.input(convert_for_kodi("Введите новое название (NAME)"), convert_for_kodi(item['name']), type=xbmcgui.INPUT_ALPHANUM)
            if new_name:
                item['name'] = new_name
                save_car_data(self.data_list)
                self.update_list()
                dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi("NAME обновлён"))
        elif edit_choice == 1:  # DATA
            new_data = dialog.input(convert_for_kodi("Введите новую дату (DATA)"), item['data'], type=xbmcgui.INPUT_DATE)
            if not new_data:
                new_data = dialog.input(convert_for_kodi("Введите дату цифрами (DDMMYYYY)"), item['data'].replace('.', ''), type=xbmcgui.INPUT_NUMERIC)
                if new_data:
                    new_data = format_date_input(new_data)
                else:
                    new_data = item['data']
            if new_data != item['data']:
                item['data'] = new_data
                save_car_data(self.data_list)
                self.update_list()
                dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi("DATA обновлён"))
        elif edit_choice == 2:  # CAR KM
            new_car_km_str = dialog.numeric(0, convert_for_kodi("Введите новый пробег (CAR KM)"), str(item['car_km']))
            if new_car_km_str:
                try:
                    item['car_km'] = int(new_car_km_str)
                    item['next_km'] = calculate_next_km(item['car_km'], item['max'])
                    save_car_data(self.data_list)
                    self.update_list()
                    dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi(f"CAR KM и NEXT KM обновлены: {item['next_km']}"))
                except ValueError:
                    dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число!"))
        elif edit_choice == 3:  # MAX
            new_max_str = dialog.numeric(0, convert_for_kodi("Введите новый интервал (MAX)"), str(item['max']))
            if new_max_str:
                try:
                    item['max'] = int(new_max_str)
                    item['next_km'] = calculate_next_km(item['car_km'], item['max'])
                    save_car_data(self.data_list)
                    self.update_list()
                    dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi(f"MAX и NEXT KM обновлены: {item['next_km']}"))
                except ValueError:
                    dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число!"))

if __name__ == '__main__':
    # Проверка, не открыт ли уже диалог
    if xbmcgui.Window(10000).getProperty('CustomDialogOpen') != 'true':
        skin_path = xbmcvfs.translatePath('special://home/addons/skin.rnspi')
        dialog = CarServiceDialog('Custom_1105_Book.xml', skin_path, 'xml', '480i')
        dialog.doModal()
        del dialog
    else:
        xbmc.log('Диалог уже открыт! Пропускаем открытие дубликата.', xbmc.LOGINFO)



































# #!/usr/bin/env python
# # -*- coding: utf-8 -*-
# import os
# import xbmc
# import xbmcgui
# import re

# #data_file = r'C:\Users\Malts\AppData\Roaming\Kodi\addons\skin.rnspi\carservice.txt'
# data_file = '/home/pi/carservice.txt'

# def convert_for_kodi(text):
    # """Конвертирует текст из UTF-8 в CP1251 для корректного отображения в Kodi"""
    # try:
        # if isinstance(text, str):
            # return text.encode('cp1251', errors='replace').decode('cp1251', errors='replace')
        # return text
    # except:
        # return str(text)  # Fallback, если конвертация не удалась

# def format_date_input(user_input):
    # if re.match(r'\d{2}\.\d{2}\.\d{4}', user_input):
        # return user_input
    # if re.match(r'\d{8}', user_input):
        # return f"{user_input[:2]}.{user_input[2:4]}.{user_input[4:]}"
    # return user_input

# def load_car_data():
    # if not os.path.exists(data_file):
        # # Изменено: дефолтные строки в новом формате
        # default_lines = [
            # "NAME (DATA) CAR KM + MAX = NEXT KM",  # Заголовок без лишних пробелов
            # "Ремень ГРМ (20.12.2020) 125000 + 8000 = 133000",
            # "Масло (20.12.2020) 125000 + 10000 = 135000"
        # ]
        # with open(data_file, 'w', encoding='utf-8') as f:
            # f.write('\n'.join(default_lines) + '\n')
        # return [
            # {"name": "Ремень ГРМ", "data": "20.12.2020", "car_km": 125000, "max": 8000, "next_km": 133000},
            # {"name": "Масло", "data": "20.12.2020", "car_km": 125000, "max": 10000, "next_km": 135000}
        # ]

    # try:
        # with open(data_file, 'r', encoding='utf-8') as f:
            # content = f.read()
    # except UnicodeDecodeError:
        # with open(data_file, 'r', encoding='cp1251') as f:
            # content = f.read()

    # lines = []
    # for line in content.splitlines():
        # line = line.strip()
        # if not line or line.startswith("NAME ("):  # Пропускаем заголовок
            # continue
        
        # # Новое: парсинг с помощью regex для формата "NAME (DATA) CAR KM + MAX = NEXT KM"
        # # Пример: "Ремень ГРМ (20.12.2020) 125000 + 8000 = 133000"
        # match = re.match(r'(.+?)\s*\(\s*([^)]+)\)\s*(\d+)\s*\+\s*(\d+)\s*=\s*(\d+)', line)
        # if match:
            # try:
                # name = match.group(1).strip()
                # data = match.group(2).strip()
                # car_km = int(match.group(3))
                # max_val = int(match.group(4))
                # next_km = int(match.group(5))
                # lines.append({
                    # "name": name,
                    # "data": data,
                    # "car_km": car_km,
                    # "max": max_val,
                    # "next_km": next_km
                # })
            # except ValueError:
                # continue  # Пропускаем некорректные строки
    # return lines

# def save_car_data(data_list):
    # try:
        # # Изменено: заголовок без лишних пробелов, формат строк как в примере
        # lines = ["NAME (DATA) CAR KM + MAX = NEXT KM"]
        # for item in data_list:
            # line = f"{item['name']} ({item['data']}) {item['car_km']} + {item['max']} = {item['next_km']}"
            # lines.append(line)
        # with open(data_file, 'w', encoding='utf-8') as f:
            # f.write('\n'.join(lines) + '\n')
    # except Exception as e:
        # xbmc.log(f"Ошибка сохранения: {str(e)}", xbmc.LOGERROR)

# def calculate_next_km(car_km, max_val):
    # return car_km + max_val

# class CarServiceDialog(xbmcgui.WindowXMLDialog):
    # def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        # super().__init__(xmlFilename, scriptPath, defaultSkin, defaultRes)
        # self.data_list = []
        # self.list_control = None  # Предполагаем, что в XML есть listcontrol с id=100

    # def onInit(self):
        # self.data_list = load_car_data()
        # self.list_control = self.getControl(100)  # ID списка в XML, предположим 100
        # self.update_list()

    # def update_list(self):
        # self.list_control.reset()
        # for item in self.data_list:
            # list_item = xbmcgui.ListItem(label=f"{convert_for_kodi(item['name'])} | {item['data']} | {item['car_km']} | {item['max']} | {item['next_km']}")
            # list_item.setProperty('name', item['name'])
            # list_item.setProperty('data', item['data'])
            # list_item.setProperty('car_km', str(item['car_km']))
            # list_item.setProperty('max', str(item['max']))
            # list_item.setProperty('next_km', str(item['next_km']))
            # self.list_control.addItem(list_item)

    # def onClick(self, controlID):
        # if controlID == 100:  # Клик на списке
            # selected_index = self.list_control.getSelectedPosition()
            # if selected_index >= 0:
                # self.edit_item(selected_index)
        # elif controlID == 200:  # Предполагаем кнопку "Добавить новую запись" с id=200
            # self.add_new_item()
        # elif controlID == 300:  # Предполагаем кнопку "Выход" с id=300
            # self.close()

    # def add_new_item(self):
        # dialog = xbmcgui.Dialog()
        # name = dialog.input(convert_for_kodi("Введите название запчасти (NAME)"), type=xbmcgui.INPUT_ALPHANUM)
        # if not name:
            # return
        # data = dialog.input(convert_for_kodi("Введите дату (DATA, формат DD.MM.YYYY)"), '', type=xbmcgui.INPUT_DATE)
        # if not data:
            # data = dialog.input(convert_for_kodi("Введите дату цифрами (DDMMYYYY)"), type=xbmcgui.INPUT_NUMERIC)
            # if data:
                # data = format_date_input(data)
            # else:
                # return
        # car_km_str = dialog.numeric(0, convert_for_kodi("Введите текущий пробег (CAR KM)"), "0")
        # if not car_km_str:
            # return
        # try:
            # car_km = int(car_km_str)
        # except ValueError:
            # dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число для CAR KM!"))
            # return
        # max_str = dialog.numeric(0, convert_for_kodi("Введите интервал (MAX, км)"), "10000")
        # if not max_str:
            # return
        # try:
            # max_val = int(max_str)
        # except ValueError:
            # dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число для MAX!"))
            # return
        # next_km = calculate_next_km(car_km, max_val)
        # self.data_list.append({"name": name, "data": data, "car_km": car_km, "max": max_val, "next_km": next_km})
        # save_car_data(self.data_list)
        # self.update_list()
        # dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi(f"Запись добавлена: {name}"))

    # def edit_item(self, index):
        # item = self.data_list[index]
        # dialog = xbmcgui.Dialog()
        # edit_choice = dialog.select(
            # convert_for_kodi(f"Редактировать: {item['name']}"),
            # [
                # f"{convert_for_kodi('NAME')}: {convert_for_kodi(item['name'])}",
                # f"{convert_for_kodi('DATA')}: {item['data']}",
                # f"{convert_for_kodi('CAR KM')}: {item['car_km']}",
                # f"{convert_for_kodi('MAX')}: {item['max']}",
                # f"{convert_for_kodi('NEXT KM')}: {item['next_km']} ({convert_for_kodi('только просмотр')})"
            # ]
        # )
        # if edit_choice == 0:  # NAME
            # new_name = dialog.input(convert_for_kodi("Введите новое название (NAME)"), convert_for_kodi(item['name']), type=xbmcgui.INPUT_ALPHANUM)
            # if new_name:
                # item['name'] = new_name
                # save_car_data(self.data_list)
                # self.update_list()
                # dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi("NAME обновлён"))
        # elif edit_choice == 1:  # DATA
            # new_data = dialog.input(convert_for_kodi("Введите новую дату (DATA)"), item['data'], type=xbmcgui.INPUT_DATE)
            # if not new_data:
                # new_data = dialog.input(convert_for_kodi("Введите дату цифрами (DDMMYYYY)"), item['data'].replace('.', ''), type=xbmcgui.INPUT_NUMERIC)
                # if new_data:
                    # new_data = format_date_input(new_data)
                # else:
                    # new_data = item['data']
            # if new_data != item['data']:
                # item['data'] = new_data
                # save_car_data(self.data_list)
                # self.update_list()
                # dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi("DATA обновлён"))
        # elif edit_choice == 2:  # CAR KM
            # new_car_km_str = dialog.numeric(0, convert_for_kodi("Введите новый пробег (CAR KM)"), str(item['car_km']))
            # if new_car_km_str:
                # try:
                    # item['car_km'] = int(new_car_km_str)
                    # item['next_km'] = calculate_next_km(item['car_km'], item['max'])
                    # save_car_data(self.data_list)
                    # self.update_list()
                    # dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi(f"CAR KM и NEXT KM обновлены: {item['next_km']}"))
                # except ValueError:
                    # dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число!"))
        # elif edit_choice == 3:  # MAX
            # new_max_str = dialog.numeric(0, convert_for_kodi("Введите новый интервал (MAX)"), str(item['max']))
            # if new_max_str:
                # try:
                    # item['max'] = int(new_max_str)
                    # item['next_km'] = calculate_next_km(item['car_km'], item['max'])
                    # save_car_data(self.data_list)
                    # self.update_list()
                    # dialog.ok(convert_for_kodi("Успешно"), convert_for_kodi(f"MAX и NEXT KM обновлены: {item['next_km']}"))
                # except ValueError:
                    # dialog.ok(convert_for_kodi("Ошибка"), convert_for_kodi("Введите корректное число!"))

# if __name__ == '__main__':
    # #dialog = CarServiceDialog('Custom_1105_Book.xml', r'C:\Users\Malts\AppData\Roaming\Kodi\addons\skin.rnspi', 'default', '1080i')
    # dialog = CarServiceDialog('Custom_1105_Book.xml', '/home/pi/.kodi/addons/skin.rnspi', 'default', 'xml')
    # dialog.doModal()
    # del dialog
